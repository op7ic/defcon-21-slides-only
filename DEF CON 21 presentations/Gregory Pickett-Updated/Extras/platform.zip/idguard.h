/*
 *	Author: gregory.pickett@hellfiresecurity.com
 *	GPLv3 License applies to this code.
 *
 * */

#include <linux/types.h>
#define DRIVER_AUTHOR "Gregory Pickett "
#define DRIVER_DESC   "IDGuard Anti-Fingerprintng Technology"

#define IP_MF               0x2000
#define IP_OFFSET           2

#define TCPOPT_EOL          0
#define TCPOPT_NOP          1
#define TCPOPT_MSS          2
#define TCPOLEN_MSS         4
#define TCPOPT_WINDOW       3
#define TCPOLEN_WINDOW      3
#define TCPOPT_SACK_PERM    4
#define TCPOLEN_SACK_PERM   2
#define TCPOPT_MD5SIG       19
#define TCPOLEN_MD5SIG      18

struct tcpopt {

	unsigned char kind;
	unsigned char length;

};
